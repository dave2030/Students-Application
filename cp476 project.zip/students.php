<?php
$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "Records";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}  
$result = mysqli_query($conn,"SELECT * FROM STUDENTS");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="pages.css" rel="stylesheet" type="text/css" />
    <script type="module" src="table_search1.js" defer></script>
    <title>Home Page</title>
  </head>
  <body>
    <div id="add_new">
      <form action="insertStudents.php" enctype="multipart/form-data" method="post">
        <h2>Add New Student</h2>

        <input
          type="number"
          name="studentnumber"
          class="input_box"
          placeholder="Student #"
          pattern="[0-9]*"
        />
        <br />

        <input
          type="text"
          name="firstname"
          class="input_box"
          placeholder="First Name"
        /><br />

        <input
          type="text"
          name="lastname"
          class="input_box"
          placeholder="Last Name"
        /><br />

        <input type="submit"></input>
      </form>
    </div>

    <h2 class="area_header">Records</h2>

    <div class="input_area">
      <label>Enter Student #: </label>
      <input
        type="number"
        class="input_box"
        placeholder="Student #"
        pattern="[0-9]*"
      />
      <button class="search_button" type="button">Search</button>

      <button class="refresh" type="button">Refresh</button>
    </div>


   <table id="records">
      <thead>
        <tr>
          <th>Student #</th>
          <th>First Name</th>
          <th>Last Name</th>
        </tr>
      </thead>

      <tbody class="table_data">

	

	<?php


while($row = mysqli_fetch_array($result)) {
?>
<tr>
    <td><?php echo $row["studentnum"]; ?></td>
    <td><?php echo $row["firstname"]; ?></td>
    <td><?php echo $row["lastname"]; ?></td>
</tr>
<?php

}
?>
	
	
      </tbody>
    </table> 
  </body>
</html>
