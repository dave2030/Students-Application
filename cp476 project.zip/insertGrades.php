<?php
$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "Records";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}  


  
$stmt=$conn->prepare("INSERT INTO GRADES (studentnum,code,grade) VALUES (?,?,?)");
$stmt->bind_param("sss",$studentNum,$code,$grade);
$studentNum=$_POST['studentnumber'];
$code=$_POST['code'];
$grade=$_POST['grade'];
// $sql = "INSERT INTO GRADES (studentnum,code,grade) 
// VALUES ($studentNum,$code,$grade)";
$stmt->execute();
echo "Inserted successfully\n";

$stmt->close();
$conn->close();
?>