<?php
$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "Records";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}  



$stmt=$conn->prepare("INSERT INTO COURSES (code,professor,coursename) VALUES (?,?,?)");
$stmt->bind_param("sss",$code,$professor,$coursename);
$code=$_POST['code'];
$professor=$_POST['professor'];
$coursename=$_POST['coursename'];

$stmt->execute();
echo "Inserted successfully\n";

$stmt->close();
$conn->close();
?>