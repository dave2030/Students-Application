
const student_search = document.querySelector(".input_area .search_button");
const student_table = document.querySelector("#records .table_data");
const student_number = document.querySelector(".input_area .input_box");
const student_reload = document.querySelector(".input_area .refresh");



student_search.addEventListener("click", (event)=> {
	console.log(student_number.value);
	const student_num_search = student_number.value;
	const rows = student_table.querySelectorAll("tr");
	console.log(rows.length)

	rows.forEach(row => {
		console.log(row)
		const row_data = row.querySelectorAll("td");
		const student_num = row_data[0].innerHTML;
		console.log(student_num);
		if (student_num_search !== student_num){
			row.classList.add("hidden_row");
		}

	});



});


student_reload.addEventListener("click", (event)=> {
	console.log(student_number.value);
	student_number.value = "";
	const rows = student_table.querySelectorAll("tr");
	console.log(rows.length)

	rows.forEach(row => {
		console.log(row)
		row.classList.remove("hidden_row");
		

	});



});