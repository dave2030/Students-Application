<?php
$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "Records";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}  
$result = mysqli_query($conn,"SELECT * FROM COURSES");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="pages.css" rel="stylesheet" type="text/css"/>
	<script type="module" src="table_search2.js" defer></script>
    <title>Home Page</title>
</head>
<body>



<div id="add_new">

<form action="insertCourses.php"
enctype="multipart/form-data"
method="post">
  <h2>Add New Course</h2>
  
  <input type="text" name="code" class="input_box" placeholder="Course Code"> <br>

    <input type="text" name="professor" class="input_box" placeholder="Professor"><br>

    <input type="text" name="coursename" class="input_box" placeholder="Course Name"><br>


    <input type="submit"></input>


</form>



</div>


<h2 class="area_header">
Records
</h2>

<div class="input_area">
    <label >Enter Course Code: </label >
    <input type="text" class="input_box" placeholder="Code" pattern="[A-Za-z]{2}[0-9]{3}">
    <button class="search_button"  type="button">Search</button>
    <button class="refresh" type="button">Refresh</button>
    </div>



<table  id="records">
  <thead>
    <tr>
        <th>Course Code</th>
        <th>Professor</th>
        <th>Course Name</th>
      </tr>
  </thead>

  <tbody class="table_data">
  <?php


while($row = mysqli_fetch_array($result)) {
?>
<tr>
<td><?php echo $row["code"]; ?></td>
    <td><?php echo $row["professor"]; ?></td>
    <td><?php echo $row["coursename"]; ?></td>
</tr>
<?php

}
?>

  </tbody>

</table>









</body>
</html>

