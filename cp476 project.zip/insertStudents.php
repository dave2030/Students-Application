<?php
$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "Records";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}  


  
$stmt=$conn->prepare("INSERT INTO STUDENTS (studentnum,firstname,lastname) VALUES (?,?,?)");
$stmt->bind_param("sss",$studentNum,$firstName,$lastName);
$studentNum=$_POST['studentnumber'];
$firstName=$_POST['firstname'];
$lastName=$_POST['lastname'];
// $sql = "INSERT INTO STUDENT (firstname, lastname, email)
// VALUES ('John', 'Doe', 'john@example.com')";
$stmt->execute();
echo "Inserted successfully\n";

$stmt->close();
$conn->close();
?>