
const search = document.querySelector(".input_area .search_button");
const table = document.querySelector("#records .table_data");
const code = document.querySelector(".input_area .input_box");
const reload = document.querySelector(".input_area .refresh");



search.addEventListener("click", (event)=> {
	console.log(code.value);
	const code_search = code.value;
	const rows = table.querySelectorAll("tr");
	console.log(rows.length)

	rows.forEach(row => {
		console.log(row)
		const row_data = row.querySelectorAll("td");
		const course_code = row_data[0].innerHTML;
		if (code_search !== course_code){
			row.classList.add("hidden_row");
		}

	});



});


reload.addEventListener("click", (event)=> {
	console.log(code.value);
	code.value = "";
	const rows = table.querySelectorAll("tr");
	console.log(rows.length)

	rows.forEach(row => {
		console.log(row)
		row.classList.remove("hidden_row");
		

	});



});