<?php
$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "Records";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}  

$studentNum=$_POST['snum'];
$grade=$_POST['sgrade'];
$code=$_POST['scode'];
$stmt=$conn->prepare("UPDATE GRADES SET grade=? WHERE studentnum=? AND code=?");
if ($stmt === false) {
  trigger_error($this->mysqli->error, E_USER_ERROR);
  return;
}
$stmt->bind_param("sss",$grade,$studentNum,$code);
$stmt->execute();
echo "Updated successfully\n";

$stmt->close();
$conn->close();
?>