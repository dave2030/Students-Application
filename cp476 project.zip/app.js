
const http = require('http')
const fs = require('fs')
const express = require('express');
const port = 80


const app = express();

app.listen(port, error => {

    if(error) {
        console.log("Something went wrong", error)
    } else{
        console.log("Server is listening on port " + port)
    }
})