<?php
$servername = "localhost";
$username = "root";
$password = "password";
$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  } 

  $sql = "CREATE DATABASE Records";
  if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
  } else {
    echo "Error creating database: " . $conn->error;
  }  

$sql = "CREATE TABLE STUDENTS(
    studentnum   VARCHAR (20)     NOT NULL,
    firstname VARCHAR (20)    NOT NULL,
    lastname VARCHAR (20)     NOT NULL,     
    PRIMARY KEY (studentnum))";
  
    if ($conn -> query($sql) === TRUE){
      echo "Table STUDENTS created successfully";
    } else {
      echo "Error creating table: " . $conn->error;
    }

$sql = "CREATE TABLE COURSES(
    code VARCHAR (10) NOT NULL,
   professor VARCHAR (20)    NOT NULL,
   name VARCHAR (20)     NOT NULL,     
   PRIMARY KEY (code))";
  
    if ($conn -> query($sql) === TRUE){
      echo "Table COURSES created successfully";
    } else {
      echo "Error creating table: " . $conn->error;
    }

    $sql = "CREATE TABLE GRADES(
        studentnum VARCHAR (20) NOT NULL,
        code VARCHAR (10)    NOT NULL,
        grade INT     NOT NULL,     
        PRIMARY KEY (studentnum, code))";
      
        if ($conn -> query($sql) === TRUE){
          echo "Table GRADES created successfully";
        } else {
          echo "Error creating table: " . $conn->error;
        }
?>
