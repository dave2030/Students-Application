<?php
$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "Records";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}  
$result = mysqli_query($conn,"SELECT * FROM GRADES");
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="pages.css" rel="stylesheet" type="text/css" />
    <script type="module" src="table_search1.js" defer></script>
    <title>Home Page</title>
  </head>
  <body>
    <div id="add_new">
      <form
        action="insertGrades.php"
        enctype="multipart/form-data"
        method="post"
      >
        <h2>Add New Grade</h2>

        <input
          type="number"
          name="studentnumber"
          class="input_box"
          placeholder="Student #"
          pattern="[0-9]*"
        />
        <br />

        <input
          type="text"
          name="code"
          class="input_box"
          placeholder="Course"
        /><br />

        <input
          type="number"
          name="grade"
          class="input_box"
          placeholder="Grade"
        /><br />

        <input type="submit"></input>
      </form>
      
    </div>

    <div id="add_new">
    <form
        action="updateGrades.php"
        enctype="multipart/form-data"
        method="post"
      >
        <h2>Update Grade</h2>

        <input
          type="number"
          name="snum"
          class="input_box"
          placeholder="Student #"
          pattern="[0-9]*"
        />
        <br />
        <input
          type="number"
          name="sgrade"
          class="input_box"
          placeholder="Grade"
        
        />
        <br />
        <input
          type="text"
          name="scode"
          class="input_box"
          placeholder="Course"
        />
        <br />

        <input type="submit"></input>
      </form>
</div>

<h2 class="area_header">Records</h2>

<div class="input_area">
  <label>Enter Student #: </label>
  <input
    type="number"
    class="input_box"
    placeholder="Student #"
    pattern="[0-9]*"
  />
  <button class="search_button" type="button">Search</button>

  <button class="refresh" type="button">Refresh</button>
</div>

<table id="records">
  <thead>
    <tr>
      <th>Student #</th>
      <th>Course Code</th>
      <th>Grade</th>
    </tr>
  </thead>

  <tbody class="table_data">

  <?php


while($row = mysqli_fetch_array($result)) {
?>
<tr>
<td><?php echo $row["studentnum"]; ?></td>
<td><?php echo $row["code"]; ?></td>
<td><?php echo $row["grade"]; ?></td>
</tr>
<?php

}
?>
  </tbody>
</table>
</body>
</html>